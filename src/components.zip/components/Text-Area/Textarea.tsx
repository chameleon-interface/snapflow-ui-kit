import { ComponentPropsWithoutRef, forwardRef, useId } from 'react'
import { clsx } from 'clsx'
import s from './Textarea.module.css'

export type TextareaProps = ComponentPropsWithoutRef<'textarea'> & {
  label?: string
  errorMessage?: string
  minHeight?: number
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ label, errorMessage, id, className, minHeight = 84, value, defaultValue, onChange, ...rest }, ref) => {
    const generatedId = useId() // всегда вызываем
    const textareaId = id ?? generatedId
    const errorId = errorMessage ? `${textareaId}-error` : undefined

    return (
      <div className={clsx(s.textareaWrapper, className)}>
        {label && <label htmlFor={textareaId} className={s.label}>{label}</label>}

        <textarea
          ref={ref}
          id={textareaId}
          className={clsx(s.textarea, { [s.errorState]: !!errorMessage })}
          aria-invalid={!!errorMessage}
          aria-describedby={errorId}
          style={{ minHeight }}
          value={value}
          defaultValue={defaultValue}
          onChange={onChange}
          {...rest}
        />

        {errorMessage && (
          <span id={errorId} role="alert" className={s.errorMessage}>
            {errorMessage}
          </span>
        )}
      </div>
    )
  }
)

Textarea.displayName = 'Textarea'
