import {
  ComponentPropsWithoutRef,
  ReactNode,
  forwardRef,
  useId, useState,
} from 'react'
import { clsx } from 'clsx'

import s from './Input.module.css'
import { EyeIcon } from '@/icons'

export type InputProps = {
  label?: string
  errorMessage?: string
  startIcon?: ReactNode
  endIcon?: ReactNode
  onEndIconClick?: () => void
  className?: string
} & ComponentPropsWithoutRef<'input'>

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, errorMessage, startIcon, endIcon, onEndIconClick, className, disabled, id, type, ...rest }, ref) => {
    const generatedId = useId()
    const inputId = id ?? generatedId
    const errorId = `${inputId}-error`
    const isError = Boolean(errorMessage)
    const [showPassword, setShowPassword] = useState(false)

    const isPassword = type === 'password' && !endIcon

    return (
      <div className={clsx(s.wrapper, className)}>
        {label && <label htmlFor={inputId} className={s.label}>{label}</label>}

        <div
          className={clsx(s.inputContainer, {
            [s.error]: isError,
            [s.disabled]: disabled,
            [s.withStartIcon]: startIcon,
            [s.withEndIcon]: endIcon || isPassword,
          })}
        >
          {startIcon && <span className={s.startIcon}>{startIcon}</span>}

          <input
            ref={ref}
            id={inputId}
            className={s.input}
            disabled={disabled}
            type={isPassword && showPassword ? 'text' : type}
            aria-invalid={isError}
            aria-describedby={isError ? errorId : undefined}
            {...rest}
          />

          {isPassword && (
            <button
              type="button"
              className={s.endIcon}
              onClick={() => setShowPassword(!showPassword)}
              aria-label={showPassword ? 'Скрыть пароль' : 'Показать пароль'}
            >
              <EyeIcon />
            </button>
          )}

          {endIcon && !isPassword && (
            <button
              type="button"
              className={s.endIcon}
              onClick={onEndIconClick}
              tabIndex={-1}
              aria-hidden={!onEndIconClick}
            >
              {endIcon}
            </button>
          )}
        </div>

        {isError && (
          <span id={errorId} className={s.errorMessage} role="alert">
            {errorMessage}
          </span>
        )}
      </div>
    )
  }
)

Input.displayName = 'Input'
