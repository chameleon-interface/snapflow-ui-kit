import type { Meta, StoryObj } from '@storybook/react-vite'
import { Input } from './Input'
import { SearchIcon } from '../../icons'

const meta = {
  title: 'Components/Input',
  component: Input,
  tags: ['autodocs'],
  parameters: { layout: 'centered' },
  argTypes: {
    label: { control: 'text' },
    placeholder: { control: 'text' },
    errorMessage: { control: 'text' },
    startIcon: { control: false },
    endIcon: { control: false },
    disabled: { control: 'boolean' },
    type: { control: 'select', options: ['text', 'email', 'password', 'search'] },
  },
} satisfies Meta<typeof Input>

export default meta
type Story = StoryObj<typeof meta>

/** Default состояние */
export const Default: Story = {
  args: {
    label: 'Email',
    placeholder: 'Введите email',
  },
}

/** Error состояние */
export const Error: Story = {
  args: {
    label: 'Email',
    placeholder: 'Введите email',
    errorMessage: 'Неверный формат',
  },
}

/** Focus состояние */
export const Focus: Story = {
  args: {
    label: 'Email',
    placeholder: 'Введите email',
    value: 'test@example.com',
  },
  play: async ({ canvasElement }) => {
    const input = canvasElement.querySelector('input') as HTMLInputElement
    input?.focus()
  },
}

/** Disabled состояние */
export const Disabled: Story = {
  args: {
    label: 'Email',
    placeholder: 'Введите email',
    value: 'Нельзя редактировать',
    disabled: true,
  },
}

/** Input с startIcon */
export const WithStartIcon: Story = {
  args: {
    label: 'Поиск',
    placeholder: 'Введите запрос',
    startIcon: <SearchIcon />,
  },
}

/** Password input с toggle eye */
export const Password: Story = {
  args: {
    label: 'Пароль',
    placeholder: 'Введите пароль',
    type: 'password',
  },
}
